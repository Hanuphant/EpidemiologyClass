## Scripts

1. Assignments/HW1/Q4/Q-4.2.1.py

SCRIPT: Q-4.2.1.py
DESCRIPTION: Script for solving the Lotka-Volterra Model
AUTHOR: Shreyash Gupta
USAGE: python Q-4.2.1.py --parameter <a> <b> <c> <d> --inits <x0> <y0> --time <Time>
GENERATES PLOTS: Assignments/HW1/Q4/Q-4.2.1-Lotka-Volterra-Model-a_1.0_b_1.0_c_1.0_d_1.0_x0_5.0_y0_2.0.png


2. Assignments/HW1/Q4/Q-4.2.3.py

SCRIPT: Q-4.2.3.py
DESCRIPTION: Script for solving the Lotka-Volterra Model 2
AUTHOR: Shreyash Gupta
USAGE: python Q-4.2.3.py -p <a> <b> <p> <g> <d> <r> <e> -i <x0> <y0> <z0> -t <time-steps>
GENERATES PLOTS: Assignments/HW1/Q4/Q-4.2.3-Lotka-Volterra-Model2-a_1.0_b_1.0_p_1.0_g_1.0_d_1.5_r_1.0_e_2.0_x0_4.0_y0_2.0_z0_5.0.png
