## Scripts

1. Assignments/HW1/Q3/Q-3.2.py

SCRIPT: Q-3.2.py
DESCRIPTION: IC Calibrated Network model
AUTHOR: Shreyash Gupta
USAGE: python Q-3.2.py --ratings Ratings.timed.csv --network network.txt
OUTPUT: Assignments/HW1/Q3/Q-3.2-Output_file.txt
GENERATES PLOTS: Assignments/HW1/Q3/Q-3.2-Weighted_out_degree_distribution.png 


